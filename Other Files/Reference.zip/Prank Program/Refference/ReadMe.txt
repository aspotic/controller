Icons were extracted with help of the Freeware utility named IconFilter.exe

Jss.mod was inserted and used in this project which was downloaded from http://www.a1vbcode.com

Codes to write REG_DWORD values was downloaded from http://www.planet-source-code.com

This program was tested on Windows 9x platforms, ME platform and XP platforms.
Couldn't find a Windows 2000 platform or Windows NT platform to test.

If any subscriber of this project gets the privilege to test this
project on a Windows 2000 or Windows NT platforms and was a success,
don't be shy to inform me also.

my email address is :- handsomeomal@yahoo.com